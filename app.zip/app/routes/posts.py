from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session
from typing import List
from .. import models, schemas, crud
from ..database import SessionLocal
from ..utils.auth import get_current_user
from ..utils.cache import cache

router = APIRouter()

# Dependency
def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()

@router.post("/addpost", response_model=schemas.Post)
def add_post(post: schemas.PostCreate, db: Session = Depends(get_db), current_user: models.User = Depends(get_current_user)):
    if len(post.text) > 1024 * 1024:
        raise HTTPException(status_code=400, detail="Post size exceeds 1MB")
    return crud.create_post(db=db, post=post, user_id=current_user.id)

@router.get("/posts", response_model=List[schemas.Post])
def get_posts(db: Session = Depends(get_db), current_user: models.User = Depends(get_current_user)):
    posts = cache.get(f"user_{current_user.id}_posts")
    if not posts:
        posts = crud.get_posts_by_user(db, user_id=current_user.id)
        cache.set(f"user_{current_user.id}_posts", posts, ttl=300)
    return posts

@router.delete("/post/{post_id}")
def delete_post(post_id: int, db: Session = Depends(get_db), current_user: models.User = Depends(get_current_user)):
    post = crud.get_post(db, post_id=post_id)
    if post is None or post.owner_id != current_user.id:
        raise HTTPException(status_code=404, detail="Post not found")
    crud.delete_post(db, post_id=post_id)
    return {"detail": "Post deleted"}
