from sqlalchemy.orm import Session
from typing import List
from .. import models, schemas

def create_post(db: Session, post: schemas.PostCreate, user_id: int):
    db_post = models.Post(**post.dict(), owner_id=user_id)
    db.add(db_post)
    db.commit()
    db.refresh(db_post)
    return db_post

def get_posts_by_user(db: Session, user_id: int) -> List[models.Post]:
    return db.query(models.Post).filter(models.Post.owner_id == user_id).all()

def get_post(db: Session, post_id: int):
    return db.query(models.Post).filter(models.Post.id == post_id).first()

def delete_post(db: Session, post_id: int):
    db_post = get_post(db, post_id=post_id)
    if db_post:
        db.delete(db_post)
        db.commit()
